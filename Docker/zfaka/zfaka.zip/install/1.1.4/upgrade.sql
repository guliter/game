INSERT INTO `t_config` (`id`, `catid`, `name`, `value`, `tag`, `lock`, `updatetime`) VALUES
(12, 1, 'index_tpl', 'default', '首页显示模式，筛选(default)|列表(list)', 1, 1453452674),
(13, 1, 'logo', '/res/images/logo.png', 'LOGO地址,默认：/res/images/logo.png', 1, 1453452674),
(14, 1, 'tongji', '/', '统计脚本', 1, 1453452674);

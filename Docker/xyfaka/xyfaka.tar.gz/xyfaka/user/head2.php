<?php

if ($conf['cdnpublic'] == 1) {
    $cdnpublic = '//lib.baomitu.com/';
} elseif ($conf['cdnpublic'] == 2) {
    $cdnpublic = '//cdn.bootcss.com/';
} elseif ($conf['cdnpublic'] == 3) {
    $cdnpublic = '//tencent.beecdn.cn/libs/';
} elseif ($conf['cdnpublic'] == 4) {
    $cdnpublic = '//s1.pstatp.com/cdn/expire-1-M/';
} else {
    $cdnpublic = '//cdn.staticfile.org/';
}
if ($conf['cdnserver'] == 1) {
    $cdnserver = '//cdn.qqzzz.net/';
} else {
    $cdnserver = '../';
}
if ($conf['ui_bing'] == 1) {
    $background_image = '//cdn.qqzzz.net/assets/img/background/' . rand(1, 19) . '.jpg';
    $conf['ui_background'] = 3;
} elseif ($conf['ui_bing'] == 2) {
    if (date("Ymd") == $conf['ui_bing_date']) {
        $background_image = $conf['ui_backgroundurl'];
        if (checkmobile() == true) $background_image = str_replace('1920x1080', '768x1366', $background_image);
    } else {
        $url = 'http://cn.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1';
        $bing_data = get_curl($url);
        $bing_arr = json_decode($bing_data, true);
        if (!empty($bing_arr['images'][0]['url'])) {
            $background_image = '//cn.bing.com' . $bing_arr['images'][0]['url'];
            saveSetting('ui_backgroundurl', $background_image);
            saveSetting('ui_bing_date', date("Ymd"));
            $CACHE->clear();
            if (checkmobile() == true) $background_image = str_replace('1920x1080', '768x1366', $background_image);
        }
    }
    $conf['ui_background'] = 3;
} else {
    $background_image = '../assets/img/bj.png';
}
@header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0,viewport-fit=cove">
    <title><?php echo $title ?></title>
    <link href="<?php echo $cdnpublic ?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="<?php echo $cdnpublic ?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo $cdnserver ?>assets/simple/css/plugins.css">
    <link rel="stylesheet" href="<?php echo $cdnserver ?>assets/simple/css/main.css">
    <link rel="stylesheet" href="<?php echo $cdnserver ?>assets/css/common.css">
    <script src="<?php echo $cdnpublic ?>modernizr/2.8.3/modernizr.min.js"></script>
    <!--[if lt IE 9]>
    <script src="<?php echo $cdnpublic ?>html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="<?php echo $cdnpublic ?>respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body>
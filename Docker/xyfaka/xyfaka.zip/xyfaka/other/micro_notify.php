<?php
exit('fail');
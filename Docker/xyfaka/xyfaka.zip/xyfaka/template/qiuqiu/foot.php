<footer id="footer">

    <div class="copyright">
        <?php echo $conf['bottom'] ?>
    </div>
</footer>

<div id="loading"></div>

</body>

</html>

DROP TABLE IF EXISTS `shua_plugin_discount_tools`;

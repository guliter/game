DROP TABLE IF EXISTS `shua_plugin_send_red_pack`;

DROP TABLE IF EXISTS `shua_plugin_send_red_pack_rule`;

ALTER TABLE `shua_pay` DROP COLUMN `is_red_pack`, DROP COLUMN `discount_money`;
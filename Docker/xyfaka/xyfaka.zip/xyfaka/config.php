<?php
/*数据库配置*/
$dbconfig=array(
	'host' => '96.45.170.249', //数据库服务器
	'port' => 6878, //数据库端口
	'user' => 'root', //数据库用户名
	'pwd' => 'qa1314521.', //数据库密码
	'dbname' => 'xyfaka', //数据库名
	'dbqz' => 'shua' //数据表前缀
);
